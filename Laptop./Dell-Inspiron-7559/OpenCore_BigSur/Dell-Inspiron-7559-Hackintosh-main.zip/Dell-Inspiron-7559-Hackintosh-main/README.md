# Dell Inspiron 7559 (Bigsur)

# Specs:
- CPU: QuadCore Intel Core i7-6700HQ, 3300 MHz (33 x 100)
- Motherboard Chipset: Intel Sunrise Point HM170, Intel Skylake-H
- iGPU: Intel Integrated HD Graphics 530
- dGPU: nVIDIA GeForce GTX 960M
- Connectivity: Intel AC 3165
- Ethernet: Realtek RTL8168/8111 PCI-E Gigabit Ethernet Adapter  	
- Audio Adapter: Realtek ALC256 @ Intel Sunrise Point PCH - High Definition Audio Controller

# Working:
- Intel HD Graphics 530 1536 MB
- Restart and Shutdown
- CPU Power Management
- Wifi, Bluetooth, Handoff (Intel AC-3165)
- Ethenet 
- Audio 
- Brightness Key (F11, F12)
- Volumes Key (F1, F2, F3)
- Touchpad
- HDMI Port
- All USB Ports

# Not Working:
- Airdrop
- SDcard Port
- dGPU: nVIDIA GeForce GTX 960M
