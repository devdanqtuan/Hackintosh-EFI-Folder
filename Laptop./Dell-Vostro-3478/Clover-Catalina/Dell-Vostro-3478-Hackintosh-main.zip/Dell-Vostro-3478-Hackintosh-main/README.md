# Catanila On Dell Vostro 3478

# Specs:
- CPU: QuadCore Intel Core i5-8250U, 3400 MHz (34 x 100)
- Motherboard Chipset: Intel Sunrise Point-LP, Intel Kaby Lake-R
- Video Adapter: Intel(R) UHD Graphics 620 (1 GB)
- Monitor: Philips 328P6V [31.5" VA LCD] (2624921104)
- Audio Adapter: Realtek ALC236 
- IDE Controller: Intel(R) 6th Generation Core Processor Family Platform I/O SATA AHCI Controller
- Connectivity: Qualcomm QCA9377 802.11ac Wireless Adapter
- Ethernet: Realtek PCIe GbE Family Controller 

# Working:
- Intel UHD Graphics 620 1536 MB
- Restart and Shutdown
- CPU Power Management
- Ethenet 
- Audio (Realtek ALC 236)
- Brightness Key 
- Volumes Key 
- Touchpad
- HDMI Port
- All USB Ports

# Not Working:
- SDcard Port
- Wifi, Bluetooth, Airdrop
