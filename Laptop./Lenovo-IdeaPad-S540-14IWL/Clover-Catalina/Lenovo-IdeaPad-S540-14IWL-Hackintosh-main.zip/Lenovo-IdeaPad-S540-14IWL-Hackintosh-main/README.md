# Lenovo-IdeaPad-S540-14IWL Hackintosh (Catalina)

# Specs:
- CPU Type: DualCore Intel Core i3-8145U, 3900 MHz (39 x 100)
- Motherboard Name: Lenovo IdeaPad S540-14IWL
- Motherboard Chipset: Intel Cannon Point-LP, Intel Whiskey Lake-U
- Video Adapter: Intel(R) UHD Graphics 620 (1 GB)
- Audio Adapter: Conexant Unknown @ Intel Cannon Point-LP PCH - cAVS (Audio, Voice, Speech) [D0]
- Keyboard: Standard PS/2 Keyboard
- Mouse: HID-compliant mouse
- Network Adapter: Realtek 8822BE Wireless LAN 802.11ac PCI-E NIC

# Working:
- Restart and Shutdown
- CPU Power Management
- Ethenet 
- Bluetooth
- Audio 
- Brightness key
- Volumes key
- Touchpad
- HDMI Port
- All USB Ports

# Not Working:
- Wifi, Handoff
- SDcard port
