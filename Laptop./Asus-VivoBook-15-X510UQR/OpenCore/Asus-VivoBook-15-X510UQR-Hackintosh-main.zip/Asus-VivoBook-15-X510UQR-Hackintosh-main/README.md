# Asus-VivoBook-15-X510UQR-Hackintosh (Bigsur)

# Specs:
- CPU Type: QuadCore Intel Core i5-8250U, 3400 MHz (34 x 100)
- Motherboard Name: Asus VivoBook 15 X510UQR
- Motherboard Chipset: Intel Sunrise Point-LP, Intel Kaby Lake-R
- Video Adapter: Intel(R) UHD Graphics 620 (1 GB)
- Audio Adapter: Conexant Unknown @ Intel Sunrise Point-LP PCH - High Definition Audio Controller 
- Disk Drive: WDC WDS120G2G0B-00EPW0 (120 GB, SATA-III)
- Network Adapter: Intel(R) Dual Band Wireless-AC 8265
- Network Adapter: Realtek RTL8188EU Wireless LAN 802.11n USB 2.0 Network Adapter


# Working:
- Intel UHD Graphics 620 
- Restart and Shutdown
- CPU Power Management
- Wifi, Bluetooth, Handoff 
- Ethenet 
- Audio 
- Brightness Key
- Volumes Key 
- Touchpad
- HDMI Port
- All USB Ports

# Not Working:
- Airdrop
- SDcard Port
