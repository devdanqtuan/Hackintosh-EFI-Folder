# Dell Vostro 15 3578 Hackintosh (Clover 5122)

# Working:
- Intel UHD 620
- Restart, Sleep and Shutdown
- CPU Power Management
- Ethenet 
- Audio
- Brightness
- Fn + Brightness (F11, F12)
- Touchpad
- HDMI
- All USB Ports

# What doesn't work:
- Wifi, Bluetooth
