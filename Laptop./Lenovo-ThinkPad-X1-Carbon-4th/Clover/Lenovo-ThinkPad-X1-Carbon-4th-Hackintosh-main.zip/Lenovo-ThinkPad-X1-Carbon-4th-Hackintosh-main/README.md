# Lenovo-ThinkPad-X1-Carbon-4th-Hackintosh (Bigsur)

# Specs:
- CPU Type: DualCore Intel Core i7-6600U, 3400 MHz (34 x 100)
- Motherboard Name: Lenovo ThinkPad X1 Carbon 4th
- Motherboard Chipset: Intel Sunrise Point-LP, Intel Skylake-U
- Video Adapter: Intel(R) HD Graphics 520 (1 GB)
- Audio Adapter:Conexant CX20753/4 @ Intel Sunrise Point-LP PCH - High Definition Audio Controller
- Network Adapter: Intel(R) Dual Band Wireless-AC 8260
- Network Adapter: Intel(R) Ethernet Connection I219-LM

# Working:
- Intel HD Graphics 520
- Restart and Shutdown
- CPU Power Management
- Wifi, Bluetooth, Handoff
- Ethenet 
- Audio (Using VoodooHDA.kext)
- Brightness Key 
- Volumes Key 
- Touchpad
- HDMI Port
- All USB Ports

# Not Working:
- Airdrop
- SDcard Port
